<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/mailchimp_callback','MailchimpController@MailchimpCallBack');
Route::post('/get_mailchimp_list','MailchimpController@getMailchimplist');
Route::post('/store_mailchimp_list','MailchimpController@storeMailchimplist');