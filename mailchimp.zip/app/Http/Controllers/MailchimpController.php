<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use PDO;
use PDOException;
use DB;
use Config;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use App\User;
use App\AppManager;
use App\UserAppManager;
use Illuminate\Support\Facades\Auth;
use Hash; 
use App\StorageConfiguration;

class MailchimpController extends Controller
{
	public $client_id = "";
	public $client_secret = "";
	public $app_url = "";
	public $redirect_uri = "";
	
	public function index(Request $request){
		$this->client_id = env("MAILCHIMP_CLIENT_ID");
		$this->client_secret = env("MAILCHIMP_CLIENT_SECRET");
	
		$auth = true;
		$error = false;
		$authurl = "https://login.mailchimp.com/oauth2/authorize?response_type=code";
    	return view('welcome',compact('authurl', 'auth','error'));
	}
	
    public function MailchimpCallBack(Request $request){
		$this->client_id = env("MAILCHIMP_CLIENT_ID");
		$this->client_secret = env("MAILCHIMP_CLIENT_SECRET");
			$auth = false;
			$error = false;
			$authurl="";
    	if(!empty($request->code)){

			$mailchimp_response = $this->CurlCall("https://login.mailchimp.com/oauth2/token","POST",array(
							"content-type: application/x-www-form-urlencoded"
									),"");
		    $mail_auth_response = json_decode($mailchimp_response);
			//echo '<pre>';print_R($mail_auth_response);

			if(!isset($mail_auth_response->access_token)){
				$error = $mail_auth_response->error;
				return view('welcome',compact('authurl', 'auth','error'));
			}else{				
				return view('dashboard',compact('tokensuccess'));
				
			}				
							
		 }else{
				$error = "code is invalid";
				return view('welcome',compact('authurl', 'auth','error'));
		 }   
	}
	
	public function getMailchimplist(Request $request){
		if(isset($_SESSION['Mailchimp_metadata']->api_endpoint)){
				
					$lists =  $this->CurlCall("/3.0/lists","GET",array( 
						// Set here required headers
						"content-type: application/json",
						"authorization: Basic ",
					),"");
		
					$list_response = json_decode($lists);

					if(isset($list_response->lists)){

						if(count($list_response->lists)>0){
							foreach($list_response->lists as $list){
								$mailchimp_list[] = ['id' => $list->id, 'name' => $list->name]; 
							}
							dd($mailchimp_list);
						}
					}
					else{
						dd($list_response);
					}
		}else{
			dd("No data found please connect mailchimp");
		}
	}


	public function CurlCall($url,$method,$header,$fields){
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30000,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => $method,
				CURLOPT_POSTFIELDS => $fields,
				CURLOPT_SSL_VERIFYHOST => 0,
				CURLOPT_SSL_VERIFYPEER => 0,
				CURLOPT_HTTPHEADER => $header,
			)); 
			
			 $response = curl_exec($curl);
			$err = curl_error($curl);
			
			curl_close($curl);
			
			if ($err) {
				return $err;
			} else {
				return $response;
			}
	}
}

