<?php
namespace App\Console\Commands\Crons;

use Illuminate\Console\Command;
use App\AppManager;
use App\UserAppManager;
use App\User;
use DB;
use Config;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use File;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotificationMail;
use RuntimeException;
use App\CronStatus;

class SimproMailchimp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'syncezy:simpro_mailchimp {action*}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Simpro Contacts update in Mailchimp';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

		$action = $this->argument('action');
		$CronStatus = CronStatus::select('id','cron_start','cron_end')->where('cron_file_name','SimproMailchimp.php')->first();
		if($CronStatus){
			if($action[0] == 'automatic'){
			CronStatus::where('id',$CronStatus->id)->update(['updated_at'=>date("Y-m-d H:i:s")]);
			}
		if(!empty($CronStatus->cron_end) || $action[0] == 'manual'){
			if($action[0] == 'automatic'){
			CronStatus::where('id',$CronStatus->id)->update(['cron_start'=>date("Y-m-d H:i:s"),'cron_end'=>'']);
			}
		  }

		if($action[0] == 'automatic'){
        $apps = AppManager::select('id','name','auth_url','client_id','client_secret','client_id_app_2','client_secret_app_2','redirect_uri_app_2','redirect_uri')->where('name','sp_tm_mp')->get();
		}else{
        $apps = AppManager::select('id','name','auth_url','client_id','client_secret','client_id_app_2','client_secret_app_2','redirect_uri_app_2','redirect_uri')->where('id',$action[1])->get();
		}

 if(count($apps)>0){
	foreach($apps as $app){			
	// decrypt code
	if($action[0] == 'automatic'){	
	   $UserAppManager = UserAppManager::select('user_app_manager.*')->leftjoin('users','users.id','=', 'user_app_manager.user_id')->where('user_app_manager.status','1')->where('users.is_active','1')->where('user_app_manager.app_manager_id',$app->id)->get();
	}else{		
	   $UserAppManager = UserAppManager::select('user_app_manager.*')->leftjoin('users','users.id','=',  'user_app_manager.user_id')->where('user_app_manager.status','1')->where('users.is_active','1')->where('user_app_manager.app_manager_id',$app->id)->where('user_app_manager.id',$action[2])->get();
	}

if(count($UserAppManager)>0){

	foreach($UserAppManager as $appdata){	
		if(!empty($appdata->auth_response_app_2)){
			
			$listid = "";
			$simpro_response = json_decode($appdata->auth_response);
			$mailchimp_response = json_decode($appdata->auth_response_app_2);
			$extradata_app_2 = json_decode($appdata->extradata_app_2);
			$company_id = $appdata->password;	
			$mailchimp_token = $mailchimp_response->access_token;
			$datacenter = $extradata_app_2->dc;
			$app_settings = json_decode($appdata->app_setting);

			if(isset($app_settings->mailchimp_list_id)){
				$listid = $app_settings->mailchimp_list_id;
			}
			
	

	 try{

		Config::set('database.connections.mysql_2.host', $appdata->db_host);
		Config::set('database.connections.mysql_2.port', $appdata->db_port);
		Config::set('database.connections.mysql_2.database', $appdata->db_name);
		Config::set('database.connections.mysql_2.username', $appdata->db_username);
		Config::set('database.connections.mysql_2.password', $appdata->db_password);					
		$db = DB::reconnect('mysql_2');					
		Schema::connection('mysql_2')->getConnection()->reconnect(); 
		
        $companies_table = 'companies';		
		//$malchimplist_table = 'mailchimplists'; 
		$fields_pairing_table = 'mailchimp_fields_pairing';	 
		$simpro_contact_sync_error_table = 'simpro_contact_sync_error';	 

		$fields_pairing_table_fields = array("simpro_id"=>"","simpro_text"=>"","mailchimp_id"=>"","mailchimp_text"=>"","is_mandatory"=>"","type"=>"","pairing_type"=>"");
		CreateSingleTable($db,$fields_pairing_table,$fields_pairing_table_fields);		
	
		$companies_table_fields = array("ID"=>"","Company_ID"=>"","Email"=>"","Type"=>"","Name"=>"","Is_Initial"=>"","synced"=>"","href"=>"","Last_modified"=>"","Web_id"=>"","Comment"=>"");
		CreateSingleTable($db,$companies_table,$companies_table_fields);

		/*$simpro_mailchimp_lists = array("id"=>"","listid"=>"","web_id"=>"","name"=>"","active"=>"","datecreated"=>"","last_modified"=>"");
		CreateSingleTable($db,$malchimplist_table,$simpro_mailchimp_lists);	*/

       
/* Setting Contacts and Customers limits starts here */
		$reclimits = "";
		$subscribed_plan =  UserSubscribeApp::select('plan_code')->where('app_complete',$appdata->id)->first();
		
			$reclimits = $zoho_plans->zoho_base_plan_limit;
		

	 $access_token = "";	
	 $auth_response_array = json_decode($appdata->auth_response_app_2);
	 if(isset($simpro_response->refresh_token)){
		$resultdata = $this->CurlCall(trim($app->auth_url)."/oauth2/token","POST",array(
			// Set here requred headers
			"accept: */*",
			"accept-language: en-US,en;q=0.8",
			"content-type: application/json",
		),json_encode(array("grant_type" => "refresh_token",
		"client_id" => $app->client_id,"client_secret" => $app->client_secret,"refresh_token" => $simpro_response->refresh_token,"state" => "")));
		$resultarray = json_decode($resultdata);					

		if(isset($resultarray->access_token)){
		$insertdata = array(
				'auth_response'=>$resultdata
				);
		$update = UserAppManager::where('id',$appdata->id)->where('user_id',$appdata->user_id)->update($insertdata);
		
		$client_url = trim($app->auth_url);
		$access_token = trim($resultarray->access_token);
		}
	}else{	
		
		$client_url = trim($simpro_response->url);
		$access_token = trim($simpro_response->access_token);
	}

	if(!empty($access_token)){ 

	 if($this->is_initialcron_done($db,$companies_table)){

	if(!empty($listid)){
	$havecustomer_data = GetTableData($db,$companies_table,array("Company_ID"=>$company_id),true); 
	
	if($havecustomer_data){			
			$customerheader=array(
			// Set here required headers
			"content-type: application/json",
			"Authorization: Bearer ". $access_token,
			"If-Modified-Since: ".$havecustomer_data->Last_modified			
			);
		}else{
			$customerheader=array(
			// Set here required headers
			"content-type: application/json",
			"Authorization: Bearer ". $access_token,
			"If-Modified-Since: ".date("D, d M Y", strtotime("-5 days"))." 12:00:00 GMT"
			);
		}

	
$company_responses = $this->GetSimproCustomers($client_url,$company_id,$customerheader);

if(is_array($company_responses['customer']) && sizeof($company_responses['customer'])){

   foreach($company_responses['customer'] as $comp_response){
	   $type='';
	   $href = $comp_response['_href'];
	   $regex1 = "/companies/"; 
	   $regex2 = "/individuals/";
	   $match1 = $match2 = array();
	   if(preg_match($regex1,$href,$match1)){	  
	   $type = 'Company'; 	
	   }	   
	   if(preg_match($regex2,$href,$match2)){	   
	   $type = 'Customer'; 	
	   }
	 
       $reccount = $db->table($companies_table)->where('synced','true')->count();

		if($reccount < $reclimits){				
			$insertdata = array("ID"=>$comp_response['ID'],
											"Company_ID"=>$company_id,
											"Name"=>$comp_response['CompanyName'],
											"type"=>$type,
											"Is_Initial"=>"false",
											'synced'=>"false",
											'href'=>$href,
											"Last_modified"=>$company_responses['lastmodified']);
		    $insertdata['created_at'] = date("Y-m-d H:i:s");
			$insertdata['updated_at'] = date("Y-m-d H:i:s");
		    $recinserted = $this->InsertUpdateDataTable($db,$companies_table,$insertdata);
		}else{				
			//deactivate user_app_manager
			$insertdata = array('status'=>0);
			$update = UserAppManager::where('id',$appdata->id)->where('user_id',$appdata->user_id)->update($insertdata); 
			$title = "simPRO Mailchimp Integration";
			$message = "simPRO Mailchimp Integration Plan Limit Has Reached .Please renew your plan limit in order to continue further. Thanks SyncEzy";
			$subject = "simPRO Mailchimp Integration Plan Limit";
			$this->sendmailchimpemail($appdata,$message,$subject,$title); 
						
		} 

	    $company_response = $this->SyncezyCustomerdetailbyHref($client_url,$access_token,$href);     
	
	
	   	if(isset($company_response['CompanyName'])){			
			$identifier = $company_response['Tags'];
			$company_response['GivenName'] = $company_response['CompanyName'];	
			$company_response['FamilyName'] = $company_response['CompanyName'];	
			$mail_response=$this->SyncezyInsertInMChimp($db,$company_response,$appdata,$identifier,'Company');
            
			if(isset($mail_response->id)){
				$contact_response=$this->ManageSimproCustomerContacts($db,$client_url,$access_token,$company_id,$company_response,$appdata,$reclimits);
			}					
		}elseif(isset($company_response['GivenName'])){			
			$identifier = $company_response['Tags'];				
			$mail_response = $this->SyncezyInsertInMChimp($db,$company_response,$appdata,$identifier,'Customer');	
		}
	}
}

		}else{
		}
	  	
		}else{
		   \Log::info("Cron => SimproMailchimp.php \n CronType = SIMPRO_MAILCHIMP \n Status = Currently Initial Cron Running \n End ".date("Y-m-d H:i:s")." \n App_id = ".$appdata->id);
		}

	  }else{
		}
	}catch (\Exception $e) {					
		echo $e->getMessage();
		$title = "Simpro with mailchimp cron is not run successfully";
	    $message = "App id: ".$appdata->id." <br>User id: ".$appdata->user_id." <br>Error:".$e->getMessage()." line:".$e->getLine();
		$subject = "Simpro with mailchimp cron is not run successfully";
		//$this->sendemail($appdata,$message,$subject,$title);
		
				
		\Log::info("Cron => SimproMailchimp.php \n CronType = SIMPRO_MAILCHIMP \n End ".date("Y-m-d H:i:s")." \n App_id = ".$appdata->id);
	   }
      }	
     }
    }
   }
  }
  CronStatus::where('id',$CronStatus->id)->update(['cron_end'=>date("Y-m-d H:i:s")]);
 }
}

public function SyncezyCustomerdetailbyHref($client_url,$access_token,$href){

	$compresponse= $this->CurlCall($client_url.$href,"GET",array("content-type: application/json","Authorization: Bearer ". $access_token),"");
    $customerdata_response = json_decode($compresponse,true);

	return $customerdata_response;


}
  

	public function GetSimproCustomerGroups($db,$token,$client_url,$company_id,$table){
		$response = $this->CurlCall($client_url."/api/v1.0/companies/".$company_id."/setup/customerGroups/","GET",array( 
													// Set here required headers
													"content-type: application/json",
													"Authorization: Bearer ". $token
												),"");	
		$custGrp_response = json_decode($response);

		 if(count($custGrp_response)>0){
			foreach($custGrp_response as $job){
			
			$insertdata = array("Company_ID"=>$company_id,"group_id"=>$job->ID,"group_name"=>$job->Name);
				$insertdata['created'] = date("Y-m-d H:i:s");
				$insertdata['last_modified'] = date("Y-m-d H:i:s");						
				$this->InsertDataTable($db,$table,$insertdata);
			}									
		  }
	   }

public function GetSimproCustomers($client_url,$company_id,$customerheader){

	    $company_pagination = true;
		$company_page = 1;
		//while($company_pagination){	
		$company_response = $this->CurlCall($client_url."/api/v1.0/companies/".$company_id."/customers/?page=".$company_page."","GET",$customerheader,"");
				
		if(isset($company_response['headers']['result-pages'][0]) && $company_response['headers']['result-pages'][0]!=0){
			if($company_response['headers']['result-pages'][0]==$company_page){
				$company_pagination = false;
			}
			//$company_page++;					
		  $companyList_response = json_decode($company_response['response'],true);
		  return array('customer'=>$companyList_response, 'lastmodified'=>$company_response['headers']['date'][0]);
		 // return $companyList_response;	  
		//}
	}
}

public function ManageSimproCustomerContacts($db,$client_url,$access_token,$company_id,$customerData,$appdata,$limits){

	 $customerID  = $customerData['ID'];
	 $identifier  = $customerData['Tags'];
	 $profiledata  = $customerData['Profile'];
	 $companies_table='companies';

	  $contact_response =	$this->CurlCall($client_url."/api/v1.0/companies/".$company_id."/customers/".$customerID."/contacts/","GET",array(	
							"content-type: application/json",
							"Authorization: Bearer ". $access_token),"");
	  $realContData = json_decode($contact_response,true);  
	 

	   if($realContData){					
			foreach($realContData as $k=>$cont){				
              $contactId=$cont['ID'];			 
			  $cont_response =	$this->CurlCall($client_url."/api/v1.0/companies/".$company_id."/customers/".$customerID."/contacts/{$contactId}","GET",array("content-type: application/json",						
			          "Authorization: Bearer ". $access_token),""); 
			   $realContactData = json_decode($cont_response,true);			 
			  
			   $count = $db->table($companies_table)->where('synced','true')->count();
			
			   if($count < $limits){
				    $Last_modified = gmdate("D, d M Y H:i:s", time())." GMT";
					$insertdata = array("ID"=>$contactId,"Company_ID"=>$company_id,"Name"=>$realContactData['GivenName'],"Email"=>$realContactData['Email'],"type"=>"Contact","synced"=>"false","Last_modified"=>$Last_modified);
					$insertdata['created_at'] = date("Y-m-d H:i:s");
					$insertdata['updated_at'] = date("Y-m-d H:i:s");
					$contactadded = $this->InsertUpdateDataTable($db,$companies_table,$insertdata);				   
			   }else{		
					//deactivate user_app_manager
					$insertdata = array('status'=>0);
					$update = UserAppManager::where('id',$appdata->id)->where('user_id',$appdata->user_id)->update($insertdata); 
			   }
			
			    $realContactData['Profile']=$customerData['Profile'];
			    $mail_response=$this->SyncezyInsertInMChimp($db,$realContactData,$appdata,$identifier,'Contact');
           	}
			
		}		
}

public function SyncezyInsertInMChimp($db,$simpro_response,$appdata,$identifier,$ConType){
	$auth_response_array = json_decode($appdata->auth_response_app_2);
    $extradata_app_2 = json_decode($appdata->extradata_app_2);
	$datacenter = $extradata_app_2->dc;
    $mc_token= $auth_response_array->access_token;	
	
	$listid='';

	$app_settings = json_decode($appdata->app_setting);
	if(isset($app_settings->mailchimp_list_id)){
		$listid = $app_settings->mailchimp_list_id;
	}

	//$malchimplist_table = 'mailchimplists';
	$companies_table = 'companies';
	$mailchimp_pairing_table = 'mailchimp_fields_pairing';
	
	//$listdata = $db->table($malchimplist_table)->where('active',1)->first();
	if($listid){
	 // $listid=$listdata->listid;
      $field_args = array();
	  if($ConType=='Company'){
		  $pairing_type='Company';
		  $field_args['SIMPROTYP']='Company';
	   }
	   if($ConType=='Customer'){
		  $pairing_type='Customer';
		  $field_args['SIMPROTYP']='Customer';
	   } 
	  if($ConType=='Contact'){
		  $pairing_type='Contact';
		  $field_args['SIMPROTYP']='Contact';
	   }
	   
	$pairing_data = GetTableData($db,$mailchimp_pairing_table,array("pairing_type"=>$pairing_type),false,false);
	$pairing_data_resp = $pairing_data->toArray();	  

	foreach($pairing_data_resp as $row){
		$dk_array = explode('-',$row->simpro_text);
		$dk = array_map('trim', $dk_array);
		$ak = $row->mailchimp_id;
		if(sizeof($dk)==2){
			/*if($ak=='ADDRESS'){
				if($dk[0]=='Address'){
					$addr1=$simpro_response['Address']['Address'];
					$city=$simpro_response['Address']['City'];
					$state=$simpro_response['Address']['State'];
					$zip=$simpro_response['Address']['PostalCode'];
                    $field_args[$ak] = array('addr1'=>$addr1,'city'=>$city,'state'=>$state,'zip'=>$zip);
                 }
				if($dk[0]=='BillingAddress'){
					$addr1=$simpro_response['BillingAddress']['Address'];
					$city=$simpro_response['BillingAddress']['City'];
					$state=$simpro_response['BillingAddress']['State'];
					$zip=$simpro_response['BillingAddress']['PostalCode'];
                  $field_args[$ak] = array('addr1'=>$addr1,'city'=>$city,'state'=>$state,'zip'=>$zip);
				}			
			}else{*/
			if(isset($simpro_response[$dk[0]][$dk[1]]))
		     $field_args[$ak] = $simpro_response[$dk[0]][$dk[1]];
			//}
			
		}elseif(sizeof($dk)==3){
		   if(isset($simpro_response[$dk[0]][$dk[1]][$dk[2]]))
		   $field_args[$ak] = $simpro_response[$dk[0]][$dk[1]][$dk[2]];
		}else{
           if(isset($simpro_response[$dk[0]]))
		   $field_args[$ak] = $simpro_response[$dk[0]];
		}
	}

if (!empty($simpro_response['Email'])){
	$email = md5(strtolower($simpro_response['Email']));	  		
	$url = "https://{$datacenter}.api.mailchimp.com/3.0/lists/$listid/members/$email";
	$auth = base64_encode( 'user:'.$mc_token );
	$getresp = $this->CurlCall($url,"GET",array( 
							// Set here required headers
							"content-type: application/json",
							"Authorization: Basic ". $auth),"");						
	  $response = json_decode($getresp);	 

	  //if not exist then create
		if($response->status==404 || (isset($response->title) && $response->title=='Resource Not Found')){

			 $auth = base64_encode( 'user:'.$mc_token );
			 $data = array("email_address"=> $simpro_response['Email'],
						  "status"=> "subscribed",
						  "merge_fields" => $field_args
						 );
		
			 $postreq = $this->CurlCall("https://{$datacenter}.api.mailchimp.com/3.0/lists/{$listid}/members","POST",array(
						"content-type: application/json",
						"Authorization: Basic ".$auth
					),json_encode($data));
			 $postresponse = json_decode($postreq);		
			
			if($postresponse->status == 'subscribed'){				
			$taginserted = $this->AddRemoveTags($simpro_response['Email'],$listid,$identifier,$mc_token,$datacenter);
			
			$syncdata = array("ID"=>$simpro_response['ID'],"Email"=>$simpro_response['Email'],"type"=>$pairing_type,"synced"=>"true","Web_id"=>$postresponse->web_id,"Comment"=>"Successfully Inserted");		
			$this->InsertUpdateDataTable($db,$companies_table,$syncdata);
			}elseif($postresponse->status == 400){				
			$syncdata = array("ID"=>$simpro_response['ID'],"Email"=>$simpro_response['Email'],"type"=>$pairing_type,"synced"=>"false","Comment"=>$postresponse->detail);		
			$this->InsertUpdateDataTable($db,$companies_table,$syncdata);
			}
			
			return $postresponse;
		}else{		

		$auth = base64_encode( 'user:'.$mc_token );
		$data = array("email_address"=> $simpro_response['Email'],
		"status"=> "subscribed",
		"merge_fields" => $field_args
		);	
	
        $response = $this->CurlCall("https://{$datacenter}.api.mailchimp.com/3.0/lists/{$listid}/members/{$email}","PATCH",array( 
																	// Set here required headers
																	"content-type: application/json",
																	"Authorization: Basic ". $auth
																),json_encode($data));

		$patchresponse = json_decode($response);
				
		$removeTags = array();		
        $currentTags= (sizeof($identifier)) ? array_column($identifier, 'Name') : array();

		if(isset($patchresponse->tags) && is_array($patchresponse->tags) && sizeof($patchresponse->tags)){
			foreach($patchresponse->tags as $tag)
		    if(!in_array($tag->name, $currentTags))$removeTags[$tag->id]=$tag->name ;
		 }
		$taginserted = $this->AddRemoveTags($simpro_response['Email'],$listid,$identifier,$mc_token,$datacenter,$removeTags);
				
		if($patchresponse->status == 'subscribed') {
			echo '<p>Customer Record Updated !</p>';
		    $syncdata = array("ID"=>$simpro_response['ID'],"Email"=>$simpro_response['Email'],"type"=>$pairing_type,"synced"=>"true","Web_id"=>$patchresponse->web_id,"Comment"=>"Successfully Updated");
			$this->InsertUpdateDataTable($db,$companies_table,$syncdata);
		}elseif($patchresponse->status == 400){				
			$syncdata = array("ID"=>$simpro_response['ID'],"Email"=>$simpro_response['Email'],"type"=>$pairing_type,"synced"=>"false","Comment"=>$patchresponse->detail);		
			$this->InsertUpdateDataTable($db,$companies_table,$syncdata);
		 }		
		return $patchresponse;		
		}
	 }else{
	        $simpro_sync_error_data = array("ID"=> $simpro_response['ID'],"Comment"=>"Contact email address not found in simPRO");
			$this->InsertUpdateDataTable($db,$companies_table,$simpro_sync_error_data);	 
	 }
	}else{
		 $simpro_sync_error_data = array("ID"=> $simpro_response['ID'],"Comment"=>"Please Select Mailchimp Audience");
		  $this->InsertUpdateDataTable($db,$companies_table,$simpro_sync_error_data);
	  return false; 
	}
	
}

public function AddRemoveTags($insertedEmail,$listid,$identifier,$mc_token,$datacenter,$removeTags = array()){    
	 /******Remove Tags From Subscriber*****/
     if(sizeof($removeTags)){		
		foreach($removeTags as $id => $name){
		$url = "https://{$datacenter}.api.mailchimp.com/3.0/lists/{$listid}/segments/{$id}";
		$auth = base64_encode( 'user:'.$mc_token );
		$emails = array( $insertedEmail );
		$data = array("members_to_remove"=>$emails);	
		$postresponse = $this->CurlCall($url,"POST",array(
						"content-type: application/json",
						"Authorization: Basic ".$auth
					),json_encode($data));	
		}	
	 }
     
	 if(sizeof($identifier)){		
     $segments = $this->getListAllSegments($listid,$mc_token,$datacenter); 	
	 
	 foreach($identifier as $tag){		
       if(array_search($tag['Name'],$segments,true) === false){		
       /*****check segment if not exist then create and add that email to segment*******/
		$url    = "https://{$datacenter}.api.mailchimp.com/3.0/lists/{$listid}/segments";	
			
		$auth   = base64_encode( 'user:'.$mc_token );
        $emails = array( $insertedEmail );
		$data   = array("name"=>$tag['Name'],'static_segment'=>$emails);
		$postresponse = $this->CurlCall($url,"POST",array(
						"content-type: application/json",
						"Authorization: Basic ".$auth
					),json_encode($data));
		}else{
		/*****check segment if exist then associate that email to segment*******/
		$segment= array_search($tag['Name'],$segments,true);
	
		$url    = "https://{$datacenter}.api.mailchimp.com/3.0/lists/{$listid}/segments/{$segment}";		
		$auth   = base64_encode( 'user:'.$mc_token );
		$emails = array( $insertedEmail );
		$data   = array("members_to_add"=>$emails);
		$postresponse = $this->CurlCall($url,"POST",array(
						"content-type: application/json",
						"Authorization: Basic ".$auth
					),json_encode($data));
		 
		}			
	 }//end foreach  
   }//end if
  return true;
 }

 /*** fetch all Segments(Tags) from a list
  ** @listid valid Mailchimp list ID.
  ** @apikey Mailchimp API key.
  **/
  public function getListAllSegments($listid,$mc_token,$datacenter){
	$url = "https://{$datacenter}.api.mailchimp.com/3.0/lists/$listid/segments?count=1600";	
	$auth   = base64_encode( 'user:'.$mc_token );	
	$response = getRequest($url,$auth);	
	$Tags = array();
	if(isset($response->segments) && sizeof($response->segments)){
		foreach($response->segments as $tag){
			$Tags[$tag->id] = $tag->name;
		}
	}	
   return $Tags;
}

	
 public function InsertDataTable($db,$tablename=null,$data=array()){
		if((count($data)>0) && !empty($tablename)){
				$db->table($tablename)->insert($data);
		return true;
		}
	return false;
   }

// insert and update in table
public function InsertUpdateDataTable($db,$tablename=null,$data=array(),$primarykey="ID"){
		if((count($data)>0) && !empty($tablename)){
			//$db::enableQueryLog();           
			$havedata = $db->table($tablename)->where('ID',$data[$primarykey])->where('type',$data['type'])->first();		
			//$query = $db::getQueryLog();				
			if($havedata){					
				$db->table($tablename)->where($primarykey,$data[$primarykey])->update($data);
			}else{				
				$db->table($tablename)->insert($data);
			}
		return true;
		}
	return false;
}


//public function is_initialcron_done($db,$table,$headerRecords){
public function is_initialcron_done($db,$table){
   
	$totrecordsync = $db->table($table)->where('Is_Initial','true')->where('synced','false')->count();
	
	if(!$totrecordsync)return true;
	else return false;	

}

public function sendmailchimpemail($appdata,$message,$subject,$title)
    {		 
		 $admins = User::where('is_admin', 1)->get();
		 if($admins){
			 foreach($admins as $admin){				
				 if(!empty($admin->user_extra_data)){
					$user_extra_data = json_decode($admin->user_extra_data);
					Mail::to($user_extra_data->notification_email,"Admin")->send(new NotificationMail($subject, $message));
				 }
			 }
		 }		
	}
public function CreateSingleTable($db,$tablename=null,$data=array()){
		$check = $db->select("SELECT COUNT(*) as `exists` FROM information_schema.tables WHERE table_name IN ('".$tablename."') AND table_schema = database()");
	
		if(!$check[0]->exists){
			if((count($data)>0) && !empty($tablename)){
				   
				$createTableSqlQuery = "CREATE TABLE IF NOT EXISTS ".$tablename." ( ";
				foreach ($data as $key => $value) {
					if(is_array($value)){
						$createTableSqlQuery .= $key." text COLLATE utf8mb4_unicode_ci DEFAULT NULL,";
					}else{
						$createTableSqlQuery .= $key." varchar(255) COLLATE utf8mb4_unicode_ci,";
					}
				}
				$createTableSqlQuery .=")";
				return $db->statement($createTableSqlQuery);
			}
		}
	return false;
}
	public function CurlCall($url,$method,$header,$fields){
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => $method,
				CURLOPT_POSTFIELDS => $fields,
				CURLOPT_SSL_VERIFYHOST => 0,
				CURLOPT_SSL_VERIFYPEER => 0,
				CURLOPT_HTTPHEADER => $header,
			)); 
			
			 $response = curl_exec($curl);
			$err = curl_error($curl);
			
			curl_close($curl);
			
			if ($err) {
				return $err;
			} else {
				return $response;
			}
	}
public function GetTableData($db,$tablename=null,$where=array(),$lastmodify=false,$all='first',$maxvalue='updated_at'){
		if(!empty($tablename)){
			$selectedtable = $db->table($tablename);
			if($lastmodify == true){
				$querywhere = "";
				if(is_array($where) && !empty($where)){
					$i = 1;
				foreach($where as $key=>$value){
					if($i>1){
						$querywhere.=" and";
					}
					$querywhere .=$key."='".$value."'";
					$selectedtable->where($key,$value);
					$i++;
				}
				}
				if(!empty($querywhere)){
					$querywhere = ' where '.$querywhere;
				}
				$havedata = $selectedtable->whereRaw($maxvalue.' = (select max('.$maxvalue.') from '.$tablename.$querywhere.')')->first();
			}else{
			if(is_array($where) && !empty($where)){
				foreach($where as $key=>$value){
					$selectedtable->where($key,$value);
				}
				if($all=='first'){
			$havedata = $selectedtable->first();
				}else{
			$havedata = $selectedtable->get();
				}
			}else{
			$havedata = $selectedtable->get();
			}
			}
		return $havedata;
		}
		return false;
}
}
